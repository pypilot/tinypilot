#!/usr/local/bin/python3

# execute and monitor this command respawning as needed
device = 'wlan0'
cmd = 'wpa_supplicant -c /etc/wpa_supplicant.conf -i ' + device

import subprocess, select, sys, atexit, os, time

os.system('sudo rm -f /var/run/wpa_supplicant/'+device)
os.system('sudo ifconfig '+device+' down')
os.system('sudo ifconfig '+device+' up')

print('wpa_supplicant_helper executing', cmd)
process = subprocess.Popen(cmd, shell=True, bufsize=5, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

def cleanup():
    print('wpa_supplicant_helper cleanup')
    time.sleep(1)
    process.terminate()
    try:
        process.wait(5)
    except:
        print('wpa_supplicant_helper failed to terminate wpa_supplicant')
        process.kill()
    
atexit.register(cleanup)
poll = select.poll()

files = [process.stdout, process.stderr]
prev_data = {}

for f in files:
    poll.register(f, select.POLLIN)
    prev_data[f] = ''

errorstrs = ['REJECT', 'CTRL-EVENT-SCAN-FAILED', 'CTRL-EVENT-DISCONNECTED']

t0 = time.monotonic()
while True:
    events = poll.poll(8000)
    while events:
        event = events.pop()
        fd, flag = event
        if flag & (select.POLLHUP | select.POLLERR | select.POLLNVAL):
            print('wpa_supplicant_helper error poll', flag)
            exit(1)
        
        for f in files:
            if fd != f.fileno():
                continue

            data = f.readline().decode()
            sys.stdout.write(data)
            sys.stdout.flush()

            combined = data + prev_data[f]
            for errorstr in errorstrs:
                if errorstr in combined:
                    print('wpa_supplicant_helper found', errorstr)
                    time.sleep(1)
                    exit(1)

            prev_data[f] = data

    if time.monotonic()-t0 > 20:
        iw = os.popen('iw ' + device + ' link')
        line = iw.readline()
        iw.close()
        if not 'Connected to' in line:
            print('wpa_supplicant_helper not connected, abort')
            time.sleep(1)
            exit(1)
