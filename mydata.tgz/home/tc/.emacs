
(cond (window-system
       (set-frame-position (selected-frame) 82 0)
       (set-frame-size (selected-frame) 83 50)
))

(setq inhibit-startup-message t)

;; Are we running XEmacs or Emacs?
(defvar running-xemacs (string-match "XEmacs\\|Lucid" emacs-version))

;; Set up the keyboard so the delete key on both the regular keyboard
;; and the keypad delete the character under the cursor and to the right
;; under X, instead of the default, backspace behavior.
;;(global-set-key [delete] 'delete-char)
;;(global-set-key [kp-delete] 'delete-char)

;(normal-erase-is-backspace-mode)

;; Turn on font-lock mode for Emacs
(cond ((not running-xemacs)
       (global-font-lock-mode t)
))

;; setup backup files
;(setq backup-directory-alist (list (cons ".*" (expand-file-name "~/.emacsbackup/"))))

;; Visual feedback on selections
;;(setq-default transient-mark-mode t)

;; Always end a file with a newline
(setq require-final-newline t)

;; Stop at the end of the file, not just add lines
(setq next-line-add-newlines nil)

;; Enable wheelmouse support by default
(cond (window-system
       (mwheel-install)
))


;;(add-to-list 'default-frame-alist '(background-color . "black"))
;;(add-to-list 'default-frame-alist '(foreground-color . "white"))
;;(add-to-list 'default-frame-alist '(erc-input-color . "green"))


(line-number-mode 1)
(column-number-mode 1)

(setq font-lock-maximum-size nil)

;(setq scroll-bar-mode nil)
;(scroll-bar-mode -1)
;(tool-bar-mode -1)
(menu-bar-mode -1)

(setq scroll-step 1)
(setq scroll-conservatively 100)

;;(set-foreground-color white)
;;(set-background-color black)

(setq auto-mode-alist
  (append '(
    ("configure.in" . m4-mode)
    ("\\.m4\\'" . m4-mode)
    ("\\.am\\'" . makefile-mode))
   auto-mode-alist))

(add-hook 'dired-load-hook (function (lambda () (load "dired-x"))))
(setq dired-omit-files-p t)

;(global-set-key [f1] 'gdb)
(global-set-key [f1] 'gud-gdb)
(global-set-key [f2] 'eshell)
(global-set-key [f3] 'shell)
(global-set-key [f4] (lambda () "" (interactive) (compile "make")))
(global-set-key [f5] (lambda () "" (interactive) (compile "make")))
(global-set-key [f6] 'run-scheme)
(global-set-key [f7] 'visit-tags-table)
(global-set-key [f8] 'add-change-log-entry-other-window)
(global-set-key [f12] 'make-frame)

(global-set-key (kbd "C-x SPC") 'gud-break)

(require 'compile)
;(set-variable compile-command "bmake")

;;(require 'gpl)
;;(require 'gpl-copying)

;;(defvar wintog nil)
;;(defun toggle-me (arg) "" (interactive "p") (if wintog (progn (setq wintog nil) (other-window arg)) (progn (setq wintog t) (other-window (- 0 arg)))))

;;(require 'color-theme)
;;(color-theme-matrix)

(cond (window-system
       (set-face-font 'menu "-*-Courier-*-r-*-*-18-*-*-*-*-*-*-*")
       (set-face-font 'default "-*-Courier-*-r-*-*-18-*-*-*-*-*-*-*")
))


;;(global-set-key "\C-x\o" 'toggle-me)

;(windmove-default-keybindings)

(transient-mark-mode t)

(setq load-path (cons "/home/sean" load-path))

(setq load-path (cons "/home/sean/build/dtrt-indent" load-path))



;(load-file "/home/sean/scheme-c/scheme.el")

;(require 'p4)
;(require 'git)

;(require 'ansi-color)
;(ansi-color-for-comint-mode-on)

;(add-to-list 'eshell-visual-commands "aaodds")

;(setq gnus-select-method)
(custom-set-variables
 ;; custom-set-variables was added by Custom.
 ;; If you edit it by hand, you could mess it up, so be careful.
 ;; Your init file should contain only one such instance.
 ;; If there is more than one, they won't work right.
 '(c-default-style (quote ((c-mode . "k&r") (c++-mode . "k&r") (java-mode . "java") (other . "gnu"))))
 '(load-home-init-file t t)
 '(safe-local-variable-values (quote ((eval progn (c-set-offset (quote innamespace) (quote 0)) (c-set-offset (quote inline-open) (quote 0)))))))
(custom-set-faces
 ;; custom-set-faces was added by Custom.
 ;; If you edit it by hand, you could mess it up, so be careful.
 ;; Your init file should contain only one such instance.
 ;; If there is more than one, they won't work right.
 )

;(server-start)
;(add-to-list 'auto-mode-alist '("/mutt" . mail-mode))


(setq c-basic-offset 4)

(add-hook 'c-mode-common-hook 
  (lambda()
    (require 'dtrt-indent)
    (dtrt-indent-mode t)))

(setq-default indent-tabs-mode nil)

(fset 'yes-or-no-p 'y-or-n-p)

(global-auto-revert-mode)

(setq case-fold-search t)

(setq enable-recursive-minibuffers t)

;(require 'gdb-ui)
