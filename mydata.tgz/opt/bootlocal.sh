#!/bin/sh
#
#   Copyright (C) 2026 Sean D'Epagnier
#
# This Program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public
# License as published by the Free Software Foundation; either
# version 3 of the License, or (at your option) any later version.  

# Start serial terminal
#/usr/sbin/startserialtty &

DEBUG=/mnt/mmcblk0p2/bootlocal.log

echo -ne "\033[9;0]" > /dev/tty1 # disable blanking
echo -e '\033[?16;0;224c' > /dev/tty1 # stop cursor from blinking

# use sdtool to disallow writing to sd card
#/opt/sdtool /dev/mmcblk0 lock

# use hdparm to disallow mounting rw
#hdparm -r1 /dev/mmcblk0
##hdparm -r1 /dev/mmcblk0p1
#hdparm -r1 /dev/mmcblk0p2

# ensure root fs is readonly
#mount /dev/mmcblk0p2 -o remount,ro

# more sane date... need to be within 20 years or so for
# gps to set the date correctly as well...
date -s 202604270100

chown tc /var/lock

date > $DEBUG

cat /proc/uptime >> $DEBUG
echo 'starting runit' >> $DEBUG
su tc -c 'tce-load -i runit' > /dev/null

runsvdir /service &
# display splash screen
cat /proc/uptime >> $DEBUG
echo 'loading libgpiod' >> $DEBUG
chpst -utc tce-load -i libgpiod  >> $DEBUG

cat /proc/uptime >> $DEBUG
echo 'showing splash' >> $DEBUG
micropython /opt/hatconfig.py >> $DEBUG
/opt/splash spi & >> $DEBUG

# load python
PYTHON=python`cat /opt/python`

cat /proc/uptime >> $DEBUG
echo 'loading python' >> $DEBUG
time chpst -utc tce-load -i $PYTHON 2>> $DEBUG

# create python3 symlink
ln -s /usr/local/bin/$PYTHON /usr/local/bin/python

cat /proc/uptime >> $DEBUG
echo 'loading serial drivers' >> $DEBUG
KERNEL=`uname -r`
chpst -utc tce-load -i usb-serial-$KERNEL > /dev/null
/sbin/modprobe i2c-dev

# start pypilot
cat /proc/uptime >> $DEBUG
echo 'loading python dependencies' >> $DEBUG
chpst -utc tce-load -i $PYTHON-serial $PYTHON-RTIMULib $PYTHON-ujson 2>> $DEBUG

cat /proc/uptime >> $DEBUG
echo 'loading pypilot' >> $DEBUG
chpst -utc tce-load -i pypilot 2>> $DEBUG

cat /proc/uptime >> $DEBUG
echo 'running pypilot' >> $DEBUG
sv u pypilot

sleep 4

cat /proc/uptime >> $DEBUG
echo 'running pypilot hat' >> $DEBUG
sv u pypilot_hat

# would be better to detect that pypilot is loaded and running instead of sleep here
sleep 8

#load pyudev
# set gpsd baud hint the first time a gps is plugged in
##cp /mnt/mmcblk0p2/.pypilot/gpsd_baud_hint /tmp
cat /proc/uptime >> $DEBUG
echo 'loading inotify and pyudev' >> $DEBUG
chpst -utc tce-load -i $PYTHON-inotify $PYTHON-pyudev > /dev/null

cat /proc/uptime >> $DEBUG
echo 'loading gpsd' >> $DEBUG
chpst -utc tce-load -i gpsd > /dev/null
sv u gpsd

# create access point
cat /proc/uptime >> $DEBUG
echo 'setting up access point' >> $DEBUG
# load wifi drivers
echo 'nameserver 8.8.8.8' > /etc/resolv.conf
echo '127.0.0.1 pool.ntp.org' >> /etc/hosts

# firmware-atheros  is quite large, omit it for now
cat /proc/uptime >> $DEBUG
echo 'ralinkwifi'
chpst -utc tce-load -i firmware-ralinkwifi >> $DEBUG

cat /proc/uptime >> $DEBUG
echo 'rtlwifi'
chpst -utc tce-load -i firmware-rtlwifi >> $DEBUG

cat /proc/uptime >> $DEBUG
echo 'rpiwifi'
chpst -utc tce-load -i firmware-rpi-wifi >> $DEBUG

cat /proc/uptime >> $DEBUG
echo 'rpiwifi'
chpst -utc tce-load -i wifi >> $DEBUG

cat /proc/uptime >> $DEBUG
echo 'wireless kernel'
chpst -utc tce-load -i wireless-$KERNEL >> $DEBUG

#if [ -e /mnt/mmcblk0p2/tinypilot/modules/$KERNEL/sha256_generic.ko ]; then
#    insmod /mnt/mmcblk0p2/tinypilot/modules/$KERNEL/sha256_generic.ko
#fi

# setup network

cat /proc/uptime >> $DEBUG
echo 'start networking' >> $DEBUG

## temp network start
#echo 'load hostapd' >> $DEBUG
# start simple network
#sudo -u tc tce-load -i hostapd >> $DEBUG
#sleep 1
#ifconfig -a >> $DEBUG
#dmesg > /mnt/mmcblk0p2/dmesg
#INTERFACE=wlan0
#ifconfig $INTERFACE up 192.168.14.1
#hostapd -B /mnt/mmcblk0p2/hostapd.conf 2>> $DEBUG
#sync
# end simple network

/opt/networking.sh >> $DEBUG
echo 'networking done' >> $DEBUG
ifconfig -a >> $DEBUG

# automatically set the date from gps
##cat /proc/uptime >> $DEBUG
##echo 'starting gpsdate service' >> $DEBUG
##sv u gpsdate

#cat /proc/uptime >> $DEBUG
echo 'loading python signalk dependencies' >> $DEBUG
chpst -utc tce-load -i $PYTHON-zeroconf $PYTHON-requests $PYTHON-websocket-client > /dev/null

# start webserver
cat /proc/uptime >> $DEBUG
echo 'starting web' >> $DEBUG
chpst -utc tce-load -i $PYTHON-flask $PYTHON-flask_socketio >> $DEBUG
chpst -utc tce-load -i $PYTHON-babel $PYTHON-flask_babel >> $DEBUG
sv u pypilot_web

# setup watchdog to watch runit
cat /proc/uptime >> $DEBUG
##echo 'starting watchdog' >> $DEBUG
##chpst -utc tce-load -i watchdog > /dev/null
##watchdog

# Start openssh daemon

cat /proc/uptime >> $DEBUG
echo 'load sshd' >> $DEBUG
chpst -utc tce-load -i openssh >> $DEBUG
cat /proc/uptime >> $DEBUG
echo 'done'
mkdir -p /var/lib/sshd
chown root:root /var/lib/sshd
chmod 755 /var/lib/sshd

cat /proc/uptime >> $DEBUG
echo 'start sshd' >> $DEBUG
#/usr/local/sbin/sshd -f /usr/local/etc/ssh/sshd_config -D -d -d -d -e 2>> $DEBUG
sv u openssh

# important stuff is loaded, sleep so it can start faster
sleep 30

# ca-certificates needed for ssl
cat /proc/uptime >> $DEBUG
echo 'loading ca-certificates' >> $DEBUG
chpst -utc tce-load -i ca-certificats > /dev/null

# scientific library needed for compass calibration
cat /proc/uptime >> $DEBUG
echo 'loading minpack' >> $DEBUG
chpst -utc tce-load -i $PYTHON-minpack > /dev/null

# load python image library used by hat lcd program if new text is drawn and not cached
cat /proc/uptime >> $DEBUG
echo 'loading python pil' >> $DEBUG
chpst -utc tce-load -i $PYTHON-PIL > /dev/null

sleep 90 # wait a while before loading development tools

# ------ Put other system startup commands below this line

cat /proc/uptime >> $DEBUG
echo 'loading tools' >> $DEBUG
chpst -utc tce-load -i screen nano > /dev/null

# Set CPU frequency governor to ondemand (default is performance)
echo ondemand > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor

sleep 60

#todo: eventually disable below as it isnt neeed for normal users

cat /proc/uptime >> $DEBUG
echo 'load dev environment' >> $DEBUG

chpst -utc tce-load -i gcc gdb binutils git emacs squashfs-tools make glibc_base-dev linux-6.12.y_api_headers pkg-config curl-dev gettext >> $DEBUG
chpst -utc tce-load -i $PYTHON-dev swig $PYTHON-setuptools > /dev/null
