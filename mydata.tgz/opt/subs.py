#!/usr/local/bin/python3

import sys
for line in sys.stdin:
    sys.stdout.write(line.replace(sys.argv[1], sys.argv[2]))
