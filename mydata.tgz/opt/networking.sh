#
#   Copyright (C) 2021 Sean D'Epagnier
#
# This Program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public
# License as published by the Free Software Foundation; either
# version 3 of the License, or (at your option) any later version.  

# configure network
NETWORK_FILE=/home/tc/.pypilot/networking.txt
MODE=`grep ^mode= $NETWORK_FILE | sed 's/mode=//g'`
SSID=`grep ^ssid= $NETWORK_FILE | sed 's/ssid=//g'`
KEY=`grep ^key=  $NETWORK_FILE | sed 's/key=//g'`
CLIENT_SSID=`grep ^client_ssid= $NETWORK_FILE | sed 's/client_ssid=//g'`
CLIENT_KEY=`grep ^client_key= $NETWORK_FILE | sed 's/client_key=//g'`
CLIENT_ADDRESS=`grep ^client_address= $NETWORK_FILE | sed 's/client_address=//g'`

# normal defaults
if [ "$SSID" = "" ]; then
    MODE="Master"
    SSID="pypilot"
    KEY=""
    CLIENT_SSID=""
    CLIENT_KEY=""
    CLIENT_ADDRESS=""
fi

echo "stop services"
# stop all networking services
sv d wpa_supplicant
sv d dhcpcd
sv d hostapd
sv d dnsmasq

unset MASTER
unset MANAGED

if [ "$MODE" = "Master+Managed" ]; then
    # test for second wireless device and create it if it does not exist
    INTERFACE=wlan1
    ifconfig $INTERFACE
    if [ $? != 0 ]; then
        chpst -utc tce-load -i iw
        iw dev wlan0 interface add $INTERFACE type __ap
        MAC=`cat /sys/class/net/wlan0/address`
        if [ $MAC == "b8:27:eb:49:7a:0c" ]; then
            MAC="b8:27:eb:49:7a:0d"
        fi
        ifconfig $INTERFACE hw ether $MAC
    fi
    
    MASTER=1
    MANAGED=1

elif [ "$MODE" = "Managed" ]; then
    MANAGED=1
else
    INTERFACE=wlan0
    CHANNEL=6
    MASTER=1
fi

echo "networking setup"
echo "mode: " $MODE
echo "managed: " $MANAGED
echo "MASTER: " $MASTER

#unset NO_DHCP
if [ -n "$MANAGED" ]; then
    cp /opt/wpa_supplicant.conf /tmp/wpa_supplicant.conf-in
    if [ "$CLIENT_KEY" = "" ]; then
        KEYMGMT="NONE"
        sed -i s/psk=/#psk=/1 /tmp/wpa_supplicant.conf-in
    else
        KEYMGMT="WPA-PSK"
    fi
    # write wpa_supplicant.conf
    cat /tmp/wpa_supplicant.conf-in | /opt/subs.py %SSID% "$CLIENT_SSID" | /opt/subs.py %KEY% "$CLIENT_KEY" | /opt/subs.py %KEYMGMT% "$KEYMGMT" > /etc/wpa_supplicant.conf
    chpst -utc tce-load -i iw
    sv u wpa_supplicant
    if [ "$CLIENT_ADDRESS" != "" ]; then
        sleep 3
        sv u fixed_ip
        #ifconfig wlan0 $CLIENT_ADDRESS
        # NO_DHCP=1
        # if failed, fallback to dhcp
    else
        chpst -utc tce-load -i dhcpcd
        sv u dhcpcd
    fi
fi

if [ -n "$MASTER" ]; then
    if [ "$KEY" = "" ]; then
        WPA=0
        KEY="notempty" #  unused field must not be empty
    else
        WPA=1
    fi

    #CHANNEL=`iwlist wlan0 channel | grep Current | sed 's/.*Channel \([0-9]*\).*/\1/g'`

    # write hostapd.conf
    cat /opt/hostapd.conf | /opt/subs.py %INTERFACE% "$INTERFACE" | /opt/subs.py %SSID% "$SSID" | /opt/subs.py %KEY% "$KEY" | /opt/subs.py %WPA% "$WPA" > /etc/hostapd.conf

    echo '192.168.14.1 pypilot' >> /etc/hosts
    echo 'start hostapd'
    date
    chpst -utc tce-load -i hostapd
    date
    sv u hostapd

    ifconfig $INTERFACE up 192.168.14.1

    cat /opt/dnsmasq.conf | /opt/subs.py %INTERFACE% "$INTERFACE" > /etc/dnsmasq.conf
    # dns and dhcp server
    echo 'start dnsmasq'
    chpst -utc tce-load -i dnsmasq
    mkdir -p /var/lib/misc
    sv u dnsmasq
fi
